=== Plugin Name ===
Contributors: fcjgodoy
Donate link: francisco.godoy@openmailbox.org
Tags: blog, one-column, custom-header, custom-menu, custom-logo, editor-style, featured-image-header, featured-images, full-width-template, microformats, sticky-post, translation-ready
Requires at least: 3.0.1
Tested up to: 4.7
Stable tag: 0.1
License: MIT License
License URI: http://opensource.org/licenses/MI

 A clone of Ghost's Casper theme for Wordpress

== Description ==

A clone of Ghost's Casper theme for Wordpress.
Dev with Sage, Bedrock and Trellis.
