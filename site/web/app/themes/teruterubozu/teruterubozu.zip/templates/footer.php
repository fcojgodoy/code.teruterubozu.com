  <footer class="content-info">
    <div class="container-fluid"> <?php // FIXME: no mezclar marcado en html con @extend ?>
      <div class="row">
        <div class="copyright"><a href="<?= esc_url( home_url( '/' ) ); ?>">Finding The Way Home</a> &copy; 2016</div>
        <div class="poweredby">Proudly published with <a href="https://wordpress.org">WordPress</a></div>
      </div>
    </div>
  </footer>
