  <footer class="content-info">
    <div class="container-fluid"> <?php // FIXME: no mezclar marcado en html con @extend ?>
      <?php dynamic_sidebar('sidebar-footer'); ?>
      <div class="row">
        <section class="copyright"><a href="http://demo.ghost.io">Finding The Way Home</a> © 2016</section>
        <section class="poweredby">Proudly published with <a href="https://wordpress.org">WordPress</a></section>
      </div>
    </div>
  </footer>

</div> <!-- END #container for Pushy -->
